import random 

gameExit = False
acc = 10
number = random.randint(1,10)
print("This is the number guessing game, where you will guess an integer between 1 and 10. You only have 5 lives, choose wisely.")
while (gameExit == False):
  x = int(input("Please guess: "))
  if x == number:
    print("You guessed correctly! You win!")
    gameExit = True
  else:
    print("Sorry but that's not right. Try another number.")
    acc -=1
  if (acc== 0):
      print("You lost! Goodbye now...")
      gameExit = True


